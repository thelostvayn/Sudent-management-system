class Student{

private int Rno;
private String Name;
private String Branch;
private String Email;
private String Mobile;
private int Subject1;
private int Subject2;
private int Subject3;

public Student(){}

public Student(int Rno, String Name, String Branch, String Email,String Mobile, int Subject1, int Subject2,int Subject3){
this.Rno = Rno;
this.Name = Name;
this.Branch = Branch;
this.Email = Email;
this.Mobile=Mobile;
this.Subject1=Subject1;
this.Subject2=Subject2;
this.Subject3=Subject3;
}

public int getRno(){return Rno; }
public String getName(){return Name; }
public String getBranch(){return Branch; }
public String getEmail(){return Email; }
public String getMobile(){return Mobile; }
public int getSubject1(){return Subject1; }
public int getSubject2(){return Subject2; }
public int getSubject3(){return Subject3; }

public void setRno(int Rno){this.Rno = Rno; }
public void setName(String Name){this.Name = Name; }
public void setBranch(String Branch){this.Branch=Branch; }
public void setEmail(String Email){this.Email=Email; }
public void setMobile(String Mobile){this.Mobile=Mobile; }
public void setSubject1(int Subject1){this.Subject1=Subject1; }
public void setSubject2(int Subject2){this.Subject2=Subject2; }
public void setSubject3(int Subject3){this.Subject3=Subject3; }

}