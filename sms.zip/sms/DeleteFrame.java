import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import org.hibernate.*;
import org.hibernate.cfg.*;
import java.sql.*;

class DeleteFrame extends JFrame{

Container c;
JLabel labDrno;
JTextField txtDrno; 
JButton btnBack, btnView, btnDelete;

DeleteFrame(){
c = getContentPane();
c.setLayout(null);

labDrno = new JLabel("roll no.");
txtDrno = new JTextField(30);
btnBack = new JButton("Back");
btnView = new JButton("View");
btnDelete = new JButton("Delete");

Font f = new Font("courier", Font.BOLD, 20);
labDrno.setFont(f);
txtDrno.setFont(f);
btnBack.setFont(f);
btnDelete.setFont(f);
btnView.setFont(f);


labDrno.setBounds(100,100,100,30);
txtDrno.setBounds(200,100,300,30);
btnBack.setBounds(225,150,100,30);
btnDelete.setBounds(550,100,100,30);
btnView.setBounds(375,150,100,30);

c.add(labDrno);
c.add(txtDrno);
c.add(btnBack);
c.add(btnView);
c.add(btnDelete);

ActionListener a1 = (ae) -> {
MainFrame a = new MainFrame();
dispose();
};
btnBack.addActionListener(a1);

ActionListener a2 = (ae) -> {
ViewFrame b = new ViewFrame();
dispose();
};
btnView.addActionListener(a2);

ActionListener a3 = (ae) -> {
Configuration cfg = new Configuration();
cfg.configure("hibernate.cfg.xml");

SessionFactory sf = cfg.buildSessionFactory();
Transaction t = null;


try(Session s = sf.openSession(); ){
	t = s.beginTransaction();

	int rno = Integer.parseInt(txtDrno.getText());
	Student stu = (Student)s.get(Student.class, rno);

	if(stu==null){
		JOptionPane.showMessageDialog(c,"Record doesn't exists");
	}
	else{
		s.delete(stu);
		t.commit();
		JOptionPane.showMessageDialog(c,"Record deleted");
	}
}
catch(Exception e) {
	JOptionPane.showMessageDialog(c, "Issue " + e);
}

};
btnDelete.addActionListener(a3);


setTitle("Delete Frame");
setSize(800,800);
setLocationRelativeTo(null);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setVisible(true);

}
}