import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

class LoginFrame extends JFrame{

Container c;
JLabel labUser, labPass;
JButton btnLogin, btnSignUp;
JTextField txtUser, txtPass;

LoginFrame(){
c = getContentPane();
c.setLayout(null);

labUser = new JLabel("Username");
txtUser = new JTextField(30);
labPass = new JLabel("Password");
txtPass = new JTextField(30);
btnLogin = new JButton("Log in");
btnSignUp = new JButton("Sign Up");

Font f = new Font("courier", Font.BOLD, 20);
labUser.setFont(f);
labPass.setFont(f);
txtUser.setFont(f);
txtPass.setFont(f);
btnSignUp.setFont(f);
btnLogin.setFont(f);


labUser.setBounds(100,100,200,30);
txtUser.setBounds(300,100,200,30);
labPass.setBounds(100,150,200,30);
txtPass.setBounds(300,150,200,30);
btnLogin.setBounds(320,200,120,30);
btnSignUp.setBounds(180,200,120,30);


c.add(labUser);
c.add(txtUser);
c.add(labPass);
c.add(txtPass);
c.add(btnLogin);
c.add(btnSignUp);

ActionListener a1 = (ae) -> {
try{
String un, pw;
un = txtUser.getText().toString();
pw = txtPass.getText().toString();

FileReader fr = new FileReader("log.txt");
BufferedReader br = new BufferedReader(fr);
String line; 

while((line=br.readLine())!=null){
if(line.matches(un + " " + pw)){
MainFrame a = new MainFrame();
dispose();
}
else{
	JOptionPane.showMessageDialog(c, "Invalid Username or Password");
	return;
	}
}
dispose();
}
catch(IOException e){
	JOptionPane.showMessageDialog(c, "Issue " + e);
}
};
btnLogin.addActionListener(a1);

ActionListener a2 = (ae) -> {
SignUpFrame a = new SignUpFrame();
dispose();
};
btnSignUp.addActionListener(a2);


setTitle("User Login");
setSize(800,800);
setLocationRelativeTo(null);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setVisible(true);

}
}