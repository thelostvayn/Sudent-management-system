import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import org.hibernate.*;
import org.hibernate.cfg.*;

class UpdateFrame extends JFrame{

Container c;
JLabel labRno, labName, labBranch, labEmail, labMobileNo,labS1, labS2, labS3;
JTextField txtRno, txtName, txtBranch, txtEmail, txtMobileNo, txtS1, txtS2, txtS3;
JButton btnUpdate, btnView, btnLogout, btnBack;

UpdateFrame(){
c = getContentPane();
c.setLayout(null);

labRno = new JLabel("Enter Roll No.");
txtRno = new JTextField(30);
labName = new JLabel("Enter New Name");
txtName = new JTextField(30);
labBranch = new JLabel("Enter New Branch");
txtBranch = new JTextField(30);
labEmail = new JLabel("Enter New Email Id");
txtEmail = new JTextField(30);
labMobileNo = new JLabel("Enter New Mobile no.");
txtMobileNo = new JTextField(30);
labS1 = new JLabel("Enter subject 1");
txtS1= new JTextField(30);
labS2 = new JLabel("Enter subject 2");
txtS2= new JTextField(30);
labS3 = new JLabel("Enter subject 3");
txtS3= new JTextField(30);
btnUpdate = new JButton("Update");
btnView = new JButton("View");
btnLogout = new JButton("Logout");
btnBack = new JButton("Back");


Font f = new Font("courier", Font.BOLD, 20);
labRno.setFont(f);
txtRno.setFont(f);
labName.setFont(f);
txtName.setFont(f);
labBranch.setFont(f);
txtBranch.setFont(f);
labEmail.setFont(f);
txtEmail.setFont(f);
labMobileNo.setFont(f);
txtMobileNo.setFont(f);
labS1.setFont(f);
txtS1.setFont(f);
labS2.setFont(f);
txtS2.setFont(f);
labS3.setFont(f);
txtS3.setFont(f);
btnUpdate.setFont(f);
btnView.setFont(f);
btnLogout.setFont(f);
btnBack.setFont(f);


labRno.setBounds(100,100,200,30);
txtRno.setBounds(350,100,300,30);
labName.setBounds(100,150,200,30);
txtName.setBounds(350,150,300,30);
labBranch.setBounds(100,200,200,30);
txtBranch.setBounds(350,200,300,30);
labEmail.setBounds(100,250,200,30);
txtEmail.setBounds(350,250,300,30);
labMobileNo.setBounds(100,300,230,30);
txtMobileNo.setBounds(350,300,300,30);
labS1.setBounds(100,350,200,30);
txtS1.setBounds(350,350,300,30);
labS2.setBounds(100,400,200,30);
txtS2.setBounds(350,400,300,30);
labS3.setBounds(100,450,200,30);
txtS3.setBounds(350,450,300,30);
btnUpdate.setBounds(200,500,120,30);
btnView.setBounds(400,500,100,30);
btnLogout.setBounds(650,25,100,30);
btnBack.setBounds(300,600,100,30);  

c.add(labRno);
c.add(txtRno);
c.add(labName);
c.add(txtName);
c.add(labBranch);
c.add(txtBranch);
c.add(labEmail);
c.add(txtEmail);
c.add(labMobileNo);
c.add(txtMobileNo);
c.add(labS1);
c.add(txtS1);
c.add(labS2);
c.add(txtS2);
c.add(labS3);
c.add(txtS3);
c.add(btnUpdate);
c.add(btnView);
c.add(btnLogout);
c.add(btnBack);

ActionListener a1 = (ae) -> {
ViewFrame a = new ViewFrame();
dispose();
};
btnView.addActionListener(a1);

ActionListener a2 = (ae) -> {

Configuration cfg = new Configuration();
cfg.configure("hibernate.cfg.xml");

SessionFactory sf = cfg.buildSessionFactory();
Transaction t = null;

try(Session s = sf.openSession(); ){

	int rno = Integer.parseInt(txtRno.getText());
	Student stu = (Student)s.get(Student.class,rno);
	if(stu==null){
		JOptionPane.showMessageDialog(c, "Roll No. doesn't exists");
		txtRno.requestFocus();	
	}
	else{

	String newName = txtName.getText();
	String newBranch = txtBranch.getText();
	String newMail = txtEmail.getText();
	String newMobile = txtMobileNo.getText();	
	String newSub1 = txtS1.getText();
	String newSub2 = txtS2.getText();
	String newSub3 = txtS3.getText();

	if(newName.length()>=2){
		if(newName.matches("[A-Za-z ]+")){
			stu.setName(newName);
		}
		else {
			JOptionPane.showMessageDialog(c, "Invalid Name");
			txtName.setText("");
			txtName.requestFocus();
			}
	}

	
	if(newBranch.length()>0){
			if(newBranch.matches("[a-zA-Z ]+")){
				stu.setBranch(newBranch);
			}
			else{
				JOptionPane.showMessageDialog(c, "Invalid Branch");
				txtBranch.setText("");
				txtBranch.requestFocus();
			}
	}


	if(newMail.length()>0){
			if(newMail.matches("^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$")){
				stu.setEmail(newMail);
			}
			else{
				JOptionPane.showMessageDialog(c, "Invalid Mail");
				txtEmail.setText("");
				txtEmail.requestFocus();
			}
	}

	if(newMobile.length()==10){
			if(newMobile.matches("[0-9]+")){
				stu.setMobile(newMobile);
			}
			else{
				JOptionPane.showMessageDialog(c, "Invalid newMobile no.");
				txtMobileNo.setText("");
				txtMobileNo.requestFocus();
			}
	}

	
	if(newSub1.length()!=0){
			int Sub1 = Integer.parseInt(newSub1);
				if(Sub1>=0 && Sub1<=100){
				stu.setSubject1(Sub1);
			}
			else{
				JOptionPane.showMessageDialog(c, "Invalid marks");
				txtS1.setText("");
				txtS1.requestFocus();
			}
		}


		if(newSub2.length()!=0){
			int Sub2 = Integer.parseInt(newSub2);
			if(Sub2>=0 && Sub2<=100){
				stu.setSubject2(Sub2);
			}
			else{
				JOptionPane.showMessageDialog(c, "Invalid marks");
				txtS2.setText("");
				txtS2.requestFocus();
			}
		}

		if(newSub3.length()!=0){
			int Sub3 = Integer.parseInt(newSub3);
			if(Sub3>=0 && Sub3<=100){
				stu.setSubject3(Sub3);				
			}
			else{
				JOptionPane.showMessageDialog(c, "Invalid marks");
				txtS3.setText("");
				txtS3.requestFocus();
			}
		}
	t = s.beginTransaction();
	s.save(stu);
	t.commit();
	JOptionPane.showMessageDialog(c, "Record updated");
	}

}
catch(NumberFormatException e){
	JOptionPane.showMessageDialog(c, "Issue " + e);
}
catch(Exception e){
	JOptionPane.showMessageDialog(c, "Issue " + e);
}

};
btnUpdate.addActionListener(a2);

ActionListener a3 = (ae) -> {
LoginFrame a = new LoginFrame();
dispose();
};
btnLogout.addActionListener(a3);

ActionListener a4 = (ae) -> {
MainFrame a = new MainFrame();
dispose();
};
btnBack.addActionListener(a4);



setTitle("Add Student");
setSize(800, 800);
setLocationRelativeTo(null);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setVisible(true);

}
}
