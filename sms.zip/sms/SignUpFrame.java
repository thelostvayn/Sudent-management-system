import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

class SignUpFrame extends JFrame{

Container c;
JLabel lbUser, lbPass, lbCfPass;
JButton btnSignUp, btnBack;
JTextField txtUser, txtPass, txtCfPass;

SignUpFrame(){
c = getContentPane();
c.setLayout(null);

lbUser = new JLabel("User Name");
lbPass = new JLabel("Password");
lbCfPass = new JLabel("Confirm Password");
txtUser = new JTextField(30);
txtPass = new JTextField(30);
txtCfPass = new JTextField(30);
btnSignUp = new JButton("SignUp");
btnBack = new JButton("Back");

Font f = new Font("courier", Font.BOLD, 20);
lbUser.setFont(f);
lbPass.setFont(f);
lbCfPass.setFont(f);
txtUser.setFont(f);
txtPass.setFont(f);
txtCfPass.setFont(f);
btnSignUp.setFont(f);
btnBack.setFont(f);

lbUser.setBounds(100,100,200,30);
lbPass.setBounds(100,150,200,30);
lbCfPass.setBounds(100,200,200,30);
txtUser.setBounds(300,100,200,30);
txtPass.setBounds(300,150,200,30);
txtCfPass.setBounds(300,200,200,30);
btnBack.setBounds(150,250,120,30);
btnSignUp.setBounds(350,250,120,30);

c.add(lbUser);
c.add(lbPass);
c.add(lbCfPass);
c.add(txtUser);
c.add(txtPass);
c.add(txtCfPass);
c.add(btnSignUp);
c.add(btnBack);

ActionListener a1 = (ae) -> {
LoginFrame a = new LoginFrame();
dispose();
	};
btnBack.addActionListener(a1);

ActionListener a2 = (ae) -> {

try{
String t1=txtUser.getText();
String t2=txtPass.getText();
String t3=txtCfPass.getText();

if(!(t1.matches("[a-zA-Z ]+"))) {
	
	JOptionPane.showMessageDialog(c, "Invalid username");
	
	}
else{
	if(t2.matches(t3)){
	try{
	FileWriter fw = new FileWriter("log.txt", true);
	fw.write(t1 +" "+ t2 + "\n");
	fw.close();
	JOptionPane.showMessageDialog(c, "Registration sucessful");
	LoginFrame a = new LoginFrame();
	dispose();
	}
	catch(Exception e){
	JOptionPane.showMessageDialog(c, "Issue " + e);
		}
	}
	else{
		JOptionPane.showMessageDialog(c, "Password Didn't matched");
		
		}
}
}
catch(Exception e){
		JOptionPane.showMessageDialog(c, "Issue " + e);

}

};
btnSignUp.addActionListener(a2);


setTitle("User SignUp");
setSize(800,800);
setLocationRelativeTo(null);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setVisible(true);

}
}