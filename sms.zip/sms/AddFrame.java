import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import org.hibernate.*;
import org.hibernate.cfg.*;
import java.sql.*;

class AddFrame extends JFrame{

Container c;
JLabel labRno, labName, labBranch, labEmail, labMobileNo,labS1, labS2, labS3;
JTextField txtRno, txtName, txtBranch, txtEmail, txtMobileNo, txtS1, txtS2, txtS3;
JButton btnSave, btnView, btnLogout, btnBack;

AddFrame(){
c = getContentPane();
c.setLayout(null);

labRno = new JLabel("Roll no.");
txtRno = new JTextField(30);
labName = new JLabel("Name");
txtName = new JTextField(30);
labBranch = new JLabel("Enter your branch");
txtBranch = new JTextField(30);
labEmail = new JLabel("Enter your Email Id");
txtEmail = new JTextField(30);
labMobileNo = new JLabel("Mobile no.");
txtMobileNo = new JTextField(30);
labS1 = new JLabel("subject 1");
txtS1= new JTextField(30);
labS2 = new JLabel("subject 2");
txtS2= new JTextField(30);
labS3 = new JLabel("subject 3");
txtS3= new JTextField(30);
btnSave = new JButton("Save");
btnView = new JButton("View");
btnLogout = new JButton("Logout");
btnBack = new JButton("Back");


Font f = new Font("courier", Font.BOLD, 20);
labRno.setFont(f);
txtRno.setFont(f);
labName.setFont(f);
txtName.setFont(f);
labBranch.setFont(f);
txtBranch.setFont(f);
labEmail.setFont(f);
txtEmail.setFont(f);
labMobileNo.setFont(f);
txtMobileNo.setFont(f);
labS1.setFont(f);
txtS1.setFont(f);
labS2.setFont(f);
txtS2.setFont(f);
labS3.setFont(f);
txtS3.setFont(f);
btnSave.setFont(f);
btnView.setFont(f);
btnLogout.setFont(f);
btnBack.setFont(f);


labRno.setBounds(100,100,200,30);
txtRno.setBounds(300,100,300,30);
labName.setBounds(100,150,200,30);
txtName.setBounds(300,150,300,30);
labBranch.setBounds(100,200,200,30);
txtBranch.setBounds(300,200,300,30);
labEmail.setBounds(100,250,200,30);
txtEmail.setBounds(300,250,300,30);
labMobileNo.setBounds(100,300,200,30);
txtMobileNo.setBounds(300,300,300,30);
labS1.setBounds(100,350,200,30);
txtS1.setBounds(300,350,300,30);
labS2.setBounds(100,400,200,30);
txtS2.setBounds(300,400,300,30);
labS3.setBounds(100,450,200,30);
txtS3.setBounds(300,450,300,30);
btnSave.setBounds(200,500,100,30);
btnView.setBounds(400,500,100,30);
btnLogout.setBounds(650,25,100,30);
btnBack.setBounds(300,600,100,30);
  

c.add(labRno);
c.add(txtRno);
c.add(labName);
c.add(txtName);
c.add(labBranch);
c.add(txtBranch);
c.add(labEmail);
c.add(txtEmail);
c.add(labMobileNo);
c.add(txtMobileNo);
c.add(labS1);
c.add(txtS1);
c.add(labS2);
c.add(txtS2);
c.add(labS3);
c.add(txtS3);
c.add(btnSave);
c.add(btnView);
c.add(btnLogout);
c.add(btnBack);

ActionListener a1 = (ae) -> {
ViewFrame a = new ViewFrame();
dispose();
};
btnView.addActionListener(a1);

ActionListener a2 = (ae) -> {

Configuration cfg = new Configuration();
cfg.configure("hibernate.cfg.xml");

SessionFactory sf = cfg.buildSessionFactory();
Transaction t = null;



try(Session s = sf.openSession(); ){
	java.util.List<Student> data = new java.util.ArrayList<>();
	data = s.createQuery("from Student").list();
	
	int rno = Integer.parseInt(txtRno.getText());
	Student stu = (Student)s.get(Student.class,rno);

	if(stu==null){
	try{
	if(Integer.parseInt(txtRno.getText())<=0){
		txtRno.setText("");
		txtRno.requestFocus();
		}
	}
	catch(NumberFormatException e){
		JOptionPane.showMessageDialog(c, "Invalid roll No");
	}

	if(txtName.getText().matches("[0-9]+")|(txtName.getText()).length()<=2){
		JOptionPane.showMessageDialog(c, "Invalid name");
		txtName.setText("");
		txtName.requestFocus();
	}
	else if(txtBranch.getText().matches("[0-9]+")|(txtBranch.getText()).length()<=0){
		JOptionPane.showMessageDialog(c, "Invalid branch");
		txtBranch.setText("");
		txtBranch.requestFocus();
	}
	else if((txtEmail.getText()).length()<=0){
		JOptionPane.showMessageDialog(c, "Invalid mail");
		txtEmail.setText("");
		txtEmail.requestFocus();
	}
	else if(txtMobileNo.getText().matches("[A-Za-z ]+")|(txtMobileNo.getText().length())<=9|(txtMobileNo.getText().length())>=11){
		JOptionPane.showMessageDialog(c, "Invalid mobile no.");
		txtMobileNo.setText("");
		txtMobileNo.requestFocus();
	}

	else if((txtS1.getText().matches("[A-Za-z ]+")) | (Integer.parseInt(txtS1.getText())<0) | (Integer.parseInt(txtS1.getText())>100)){
		JOptionPane.showMessageDialog(c, "Invalid marks");
		txtS1.setText("");
		txtS1.requestFocus();
	}
	else if((txtS2.getText().matches("[A-Za-z ]+")) | (Integer.parseInt(txtS2.getText())<0) | (Integer.parseInt(txtS2.getText())>100)) {
		JOptionPane.showMessageDialog(c, "Invalid marks");
		txtS2.setText("");
		txtS2.requestFocus();
		}
	else if((txtS3.getText().matches("[A-Za-z ]+"))|(Integer.parseInt(txtS3.getText())<0)|(Integer.parseInt(txtS3.getText())>100)){
		JOptionPane.showMessageDialog(c, "Invalid marks");
		txtS3.setText("");
		txtS3.requestFocus();
	}
	else{
			rno = Integer.parseInt(txtRno.getText());
			int s1 = Integer.parseInt(txtS1.getText());
			int s2 = Integer.parseInt(txtS2.getText());
			int s3 = Integer.parseInt(txtS3.getText());
			String sname = txtName.getText();
			String sbranch = txtBranch.getText();
 			String smail = txtEmail.getText();
			String smobile = txtMobileNo.getText();

		Student st = new Student(rno, sname, sbranch, smail, smobile, s1, s2, s3);
		t = s.beginTransaction();
		s.save(st);
		t.commit();
		JOptionPane.showMessageDialog(c, "Record created");	
		}
	}
	else{
		JOptionPane.showMessageDialog(c, "Roll No. already exists");
		txtRno.setText("");
		txtRno.requestFocus();	
	}
	}
catch(NumberFormatException e){
	JOptionPane.showMessageDialog(c, "Invalid Marks");
}
catch(Exception e){	
	JOptionPane.showMessageDialog(c, "Issue " + e);
}

};
btnSave.addActionListener(a2);

ActionListener a3 = (ae) -> {
LoginFrame a = new LoginFrame();
dispose();
};
btnLogout.addActionListener(a3);

ActionListener a4 = (ae) -> {
MainFrame a = new MainFrame();
dispose();
};
btnBack.addActionListener(a4);

setTitle("Add Student");
setSize(800, 800);
setLocationRelativeTo(null);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setVisible(true);
}
}
