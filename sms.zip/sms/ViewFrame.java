import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

class ViewFrame extends JFrame{

Container c;
TextArea taData;
JButton btnBack;

ViewFrame(){
c = getContentPane();
c.setLayout(null);

taData = new TextArea(10,50);
btnBack = new JButton("Back");


taData.setBounds(25,100,750,400);
btnBack.setBounds(350,500,100,30);



StringBuffer data = new StringBuffer();
try{
	DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
	String url = "jdbc:mysql://localhost:3306/kc9july22";
	String un = "root";
	String pw = "dee123";
	Connection con = DriverManager.getConnection(url, un, pw);

	String sql = "select * from studentdata";
	Statement stmt = con.createStatement();
	ResultSet rs = stmt.executeQuery(sql);

	while(rs.next()){
	String rno = rs.getString(1);
	String name = rs.getString(2);
	String Branch = rs.getString(3);
	String Email = rs.getString(4);
	String mobile = rs.getString(5);
	String s1 = rs.getString(6);
	String s2 = rs.getString(7);
	String s3= rs.getString(8);
	data.append("Roll no:- "+rno+" Name:- "+name+" Branch:- "+Branch+" Email Id:- "+Email+" Mobile No:- "+mobile+" Subject 1:- "+s1+" Subject 2:- "+s2+" Subject 3:- "+s3+"\n");
	}
	taData.setText(data.toString());
	con.close();
}
catch(SQLException e){
	JOptionPane.showMessageDialog(c,"issue " + e);
}
catch(Exception e){
	JOptionPane.showMessageDialog(c,"issue " + e);
}

c.add(taData);
c.add(btnBack);


ActionListener a1 = (ae) -> {
MainFrame a = new MainFrame();
dispose();
};
btnBack.addActionListener(a1);


setTitle("View Student");
setSize(800,800);
setLocationRelativeTo(null);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setVisible(true);

}
}

