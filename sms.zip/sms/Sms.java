class Sms{
public static void main(String Args[]){
LoginFrame l = new LoginFrame();

}

}